from backend.app.factories.match_factory import MatchFactory
from backend.app.gateways.match_gateways import MatchGateway
from backend.app.models.redis.match_mission import MatchMission
class MatchMissionRepo:
    def __init__(self) -> None:
        self.match_gateway=MatchGateway()
        self.match_factory=MatchFactory()
    def get_match_mission_by_id(self,match_id, mission_id):
        for mission in self.get_all_match_missions(match_id):
            if mission["mission_id"] == mission_id:
                return mission

        return None


    def get_match_mission_by_owner_id(self,match_id, owner_id):
        for mission in self.get_all_match_missions(match_id):
            if mission["owner_id"] == owner_id:
                return mission

        return None


    def create_match_mission(self,match_id,mission_id,type,content,owner_id):
        match_mission=MatchMission(
            match_id=match_id,
            mission_id=mission_id,
            type=type,content=content,
            owner_id=owner_id
        )
        match_mission_dict=match_mission.to_dict()
        

        return match_mission_dict


    def save_match_missions(self,match_id, match_missions):
        match_dict = self.match_gateway.get_match(match_id)

        match_dict["missions"] = match_missions

        self.match_factory.update_match(match_dict)

        return match_missions

    def update_match_mission(self,match_id, updated_match_mission):
        match_dict = self.match_gateway.get_match(match_id)

        missions = match_dict.get("missions", [])

        for index, mission in enumerate(missions):
            if mission["owner_id"] == updated_match_mission["owner_id"]:
                missions[index] = updated_match_mission
                self.match_factory.update_match(match_dict)
                return updated_match_mission

        raise ValueError("Missão do jogador não encontrada.")
    def get_all_match_missions(self,match_id):
            match_dict = self.match_gateway.get_match(match_id)
    
            if match_dict is None:
                raise ValueError("Partida não encontrada.")
    
            return match_dict.get("missions", [])
    
    