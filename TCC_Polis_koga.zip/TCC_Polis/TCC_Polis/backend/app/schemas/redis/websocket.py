# Formato das mensagens WebSocket.
