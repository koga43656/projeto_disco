# Criar jogador, nickname, recursos.
# Busca/salva players temporários no Redis.

from backend.app.gateways.player_gateways import PlayerGateway
from backend.app.factories.player_factory import PlayerFactory

from backend.app.gateways.db.user_gateways import UsersGateway
from backend.app.validators.user_validators import UserValidator


player_gateway = PlayerGateway()
player_factory = PlayerFactory()

user_gateway = UsersGateway()
user_validator = UserValidator()

def create_player(username=None,party_id=None):
    player_dict = player_factory.create_player(username=username,party_id=party_id)
    return player_dict

def create_user_player(db,user_id):
    user = user_gateway.get_user(db,user_id)
    user = user_validator.not_exist(user)
    existing_player = None
    if user.player_id is not None:
        existing_player = (player_gateway.get_player(user.player_id))
    user_validator.user_can_create_player(user,existing_player)   
    if (user.player_id is not None and existing_player is None):
        user.player_id = None
        db.commit()
        db.refresh(user)
    player_dict = player_factory.create_player(username=user.username)
    user.player_id = player_dict["player_id"]
    db.commit()
    db.refresh(user)

    return player_dict

def get_player(player_id):
    return player_gateway.get_player(player_id)

def delete_user_player(db, user_id):  
    user = user_gateway.get_user(db,user_id)
    user = user_validator.not_exist(user)
    if user.player_id is None:
        return None
    player_id = user.player_id
    player_gateway.delete_player(player_id)
    user.player_id = None
    db.commit()
    db.refresh(user)
    return user

def delete_player(player_id):
    return player_gateway.delete_player(player_id)